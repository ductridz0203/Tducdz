// light_aim.cpp
#include <iostream>

class AimSystem {
public:
    float aimSensitivity = 1.0f;  // Cấp Độ Nhạy Của Tâm

    void adjustAim(float level) {
        aimSensitivity -= level;  // giảm độ nhạy tâm để chuyển sang thành nhẹ tâm
        if (aimSensitivity < 0.1f) {
            aimSensitivity = 0.1f;  // Đảm bảo không giảm quá mức
        }
    }

    void displaySensitivity() {
        std::cout << "Current aim sensitivity: " << aimSensitivity << std::endl;
    }
};

int main() {
    AimSystem aim;
    aim.adjustAim(0.3f);  // phần này giảm nhạy tâm nếu muốn tăng thì cũng được
    aim.displaySensitivity();
    return 0;
}