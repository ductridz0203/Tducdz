// anti_code_disorder.cpp
#include <iostream>
#include <string>
#include <vector>
#include <map>

class CodeFlowStabilizer {
private:
    std::map<std::string, std::string> logicMap;
    std::vector<std::string> executionOrder;

public:
    void defineLogic(const std::string& key, const std::string& action) {
        logicMap[key] = action;
        executionOrder.push_back(key);
    }

    void executeInOrder() {
        std::cout << "Executing logic in stable order:\n";
        for (const auto& key : executionOrder) {
            std::cout << " - [" << key << "]: " << logicMap[key] << std::endl;
        }
    }
};

int main() {
    CodeFlowStabilizer stabilizer;

    stabilizer.defineLogic("Init", "Initialize system");
    stabilizer.defineLogic("Load", "Load resources");
    stabilizer.defineLogic("Optimize", "Apply performance boost");
    stabilizer.defineLogic("Render", "Render output");

    stabilizer.executeInOrder();  // Đảm Bảo An Toàn Không Bị Rối Loạn Phần Code Khi Ae Chèn Code Vào

    return 0;
}