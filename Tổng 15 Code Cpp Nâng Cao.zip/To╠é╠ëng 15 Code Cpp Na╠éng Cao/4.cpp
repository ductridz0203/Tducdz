// high_sensitivity_aim.cpp
#include <iostream>

class HighSensitivityAim {
public:
    float sensitivityLevel = 1.0f;  // độ nhạy của tâm

    void increaseSensitivity(float increment) {
        sensitivityLevel += increment;  // Tăng độ nhạy của tâm
        if (sensitivityLevel > 5.0f) {
            sensitivityLevel = 5.0f;  // Giới hạn độ nhạy tối đa
        }
        std::cout << "Aim sensitivity increased to: " << sensitivityLevel << std::endl;
    }

    void displaySensitivity() {
        std::cout << "Current aim sensitivity: " << sensitivityLevel << std::endl;
    }
};

int main() {
    HighSensitivityAim aim;
    aim.increaseSensitivity(1.5f);  // Tăng độ nhạy của tâm
    aim.displaySensitivity();
    return 0;
}