// close_range_head_lock.cpp
#include <iostream>
#include <cmath>

class CloseRangeHeadLock {
private:
    float headX = 0.0f;
    float headY = 0.0f;
    const float lockDistance = 2.0f;  // Độ Gần Khi Bắt Đầu "khoá đầu"

public:
    void setEnemyHeadPosition(float x, float y) {
        headX = x;
        headY = y;
        std::cout << "Enemy head position set at (" << headX << ", " << headY << ")\n";
    }

    void lockOn(float playerX, float playerY) {
        float distance = std::sqrt(std::pow(headX - playerX, 2) + std::pow(headY - playerY, 2));
        if (distance <= lockDistance) {
            std::cout << "Close-range head lock activated! Precise tracking in effect.\n";
        } else {
            std::cout << "Target too far. Close-range lock not triggered.\n";
        }
    }
};

int main() {
    CloseRangeHeadLock closeLock;
    closeLock.setEnemyHeadPosition(30.0f, 45.0f);
    closeLock.lockOn(31.2f, 44.5f);  // Vị Trí Của Kẻ Địch Ở Tầm Gần
    return 0;
}