// aim_stabilization.cpp
#include <iostream>

class AimStabilizer {
public:
    float aimStability = 0.5f;  // Độ ổn định của phần tâm

    void stabilizeAim() {
        // Giảm dao động của tâm, Tăng ổn định hơn và khi di chuyển
        aimStability += 0.2f;  // Tăng độ ổn định cao
        if (aimStability > 1.0f) {
            aimStability = 1.0f;  // độ ổn định không vượt quá 1.0
        }
        std::cout << "Aim stabilized at: " << aimStability << std::endl;
    }

    void displayStability() {
        std::cout << "Current aim stability: " << aimStability << std::endl;
    }
};

int main() {
    AimStabilizer stabilizer;
    stabilizer.stabilizeAim();  //   Phần Đầm Tâm
    stabilizer.displayStability();
    return 0;
}