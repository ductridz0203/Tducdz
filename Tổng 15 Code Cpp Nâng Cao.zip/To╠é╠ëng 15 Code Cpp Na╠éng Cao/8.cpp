// neck_lock.cpp
#include <iostream>
#include <cmath>

class NeckLock {
private:
    float neckX = 0.0f;
    float neckY = 0.0f;
    const float lockRadius = 3.0f;  // phạm vi của việc bám vào vùng cổ

public:
    void setNeckPosition(float x, float y) {
        neckX = x;
        neckY = y;
        std::cout << "Target neck position set at (" << neckX << ", " << neckY << ")\n";
    }

    void lockToNeck(float aimX, float aimY) {
        float distance = std::sqrt(std::pow(neckX - aimX, 2) + std::pow(neckY - aimY, 2));
        if (distance <= lockRadius) {
            std::cout << "Locked onto the neck! Tracking steady.\n";
        } else {
            std::cout << "Not within neck lock zone. Adjusting aim...\n";
        }
    }
};

int main() {
    NeckLock neckTracker;
    neckTracker.setNeckPosition(60.0f, 70.0f);
    neckTracker.lockToNeck(59.0f, 68.8f);  // tâm bám vào gần cổ
    return 0;
}