// lock_head_region.cpp
#include <iostream>
#include <cmath>

class HeadRegionLock {
private:
    float targetX = 0.0f;
    float targetY = 0.0f;
    const float lockThreshold = 3.0f;  // Độ khóa chặt trong tầm gần

public:
    void setTarget(float x, float y) {
        targetX = x;
        targetY = y;
        std::cout << "Target head region set at (" << targetX << ", " << targetY << ")" << std::endl;
    }

    bool isLocked(float currentX, float currentY) {
        float distance = std::sqrt(std::pow(currentX - targetX, 2) + std::pow(currentY - targetY, 2));
        return distance <= lockThreshold;
    }

    void checkLock(float currentX, float currentY) {
        if (isLocked(currentX, currentY)) {
            std::cout << "Head region locked: Stable on target.\n";
        } else {
            std::cout << "Head region NOT locked: Adjusting...\n";
        }
    }
};

int main() {
    HeadRegionLock lock;
    lock.setTarget(50.0f, 50.0f);
    lock.checkLock(52.5f, 48.7f);  // vị trí hiện tại để kiểm tra lock
    return 0;
}