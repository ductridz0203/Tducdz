// cpu_optimization.cpp
#include <iostream>
#include <thread>
#include <vector>

class CPUOptimizer {
public:
    void optimizeThreads(int threadCount) {
        std::cout << "Optimizing CPU with " << threadCount << " lightweight threads...\n";

        std::vector<std::thread> threads;
        for (int i = 0; i < threadCount; ++i) {
            threads.emplace_back([i]() {

                std::cout << "Thread " << i << " running optimization task...\n";
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                std::cout << "Thread " << i << " completed.\n";
            });
        }

        for (auto& t : threads) {
            if (t.joinable()) t.join();
        }

        std::cout << "CPU optimization complete. All lightweight tasks finished.\n";
    }
};

int main() {
    CPUOptimizer optimizer;
    optimizer.optimizeThreads(4);  // Phần Tối Ưu
    return 0;
}