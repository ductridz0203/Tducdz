// head_tracking.cpp
#include <iostream>

class HeadTracking {
public:
    float headPositionX = 0.0f;  // Vị trí trục X của phần đầu
    float headPositionY = 0.0f;  // Vị trí trục Y của phần đầu

    void trackHead(float x, float y) {
        // vị trí phần đầu
        headPositionX = x;
        headPositionY = y;
        std::cout << "Tracking head at position (" << headPositionX << ", " << headPositionY << ")" << std::endl;
    }

    void displayHeadPosition() {
        std::cout << "Current head position: (" << headPositionX << ", " << headPositionY << ")" << std::endl;
    }
};

int main() {
    HeadTracking tracker;
    tracker.trackHead(10.5f, 20.3f);  // Giả lập bám đầu vị trí X=10.5, Y=20.3
    tracker.displayHeadPosition();
    return 0;
}