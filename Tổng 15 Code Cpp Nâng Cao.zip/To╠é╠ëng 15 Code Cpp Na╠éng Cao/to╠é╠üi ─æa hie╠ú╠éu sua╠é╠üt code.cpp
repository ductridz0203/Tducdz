// code_efficiency.cpp
#include <iostream>
#include <chrono>

class CodeEfficiency {
public:
    void runOptimizedRoutine() {
        auto start = std::chrono::high_resolution_clock::now();

        // tối ưu hóa vòng lặp, tránh thừa việc tối ưu
        int result = 0;
        for (int i = 1; i <= 1000000; ++i) {
            result += i;
        }

        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> duration = end - start;

        std::cout << "Optimized computation result: " << result << std::endl;
        std::cout << "Execution time (optimized): " << duration.count() << " seconds\n";
    }
};

int main() {
    CodeEfficiency efficiency;
    efficiency.runOptimizedRoutine();
    return 0;
}